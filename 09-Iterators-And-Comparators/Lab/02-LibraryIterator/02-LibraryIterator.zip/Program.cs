﻿using System;

namespace IteratorsAndComparators
{
    public class Program
    {
        public static void Main()
        {
         
        }
    }
}
