﻿
public class Cargo
{
    public double Weight { get; set; }
    public string Type { get; set; }

    public Cargo(double weight, string type)
    {
        Weight = weight;
        Type = type;
    }
}

